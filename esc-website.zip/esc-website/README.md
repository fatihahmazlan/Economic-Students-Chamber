# Economics Students’ Chamber (ESC) — Website

A simple, fast, **no-build** website for the Economics Students’ Chamber, Brunei Darussalam.
Brand colours: **#62160d** (base) and **#FFC549** (accent).

## What’s inside

| Feature | Where |
|---|---|
| Animated hero, scrolling indicator ticker, scroll-reveal motion | `js/main.js`, `css/style.css` |
| Vision, mission, objectives | `index.html` → `#about` |
| Brunei economy dashboard (live World Bank data, KPI cards, 6 charts) | `js/dashboard.js` |
| Data hub: compare countries, download CSV, Brunei + international sources | `js/explorer.js`, `js/config.js` |
| Regression lab: OLS, p-values, log forms, prediction, World Bank loader | `js/regression.js`, `js/stats.js` |
| **Esync** AI assistant (chat widget) | `js/esync.js`, `kb` in `js/config.js` |

## Run it on your computer

Just double-click `index.html`, or for a more realistic test:

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## Put it on GitHub (and host it free)

1. Create a new repository on GitHub, e.g. `esc-website`.
2. Upload everything in this folder (or use the commands below).
3. In the repo: **Settings → Pages → Build and deployment → Source: “Deploy from a branch”**, choose branch `main` and folder `/ (root)`, then **Save**.
4. After a minute your site is live at `https://<your-username>.github.io/esc-website/`.

```bash
git init
git add .
git commit -m "Initial ESC website"
git branch -M main
git remote add origin https://github.com/<your-username>/esc-website.git
git push -u origin main
```

## Edit your content

- **Contact details, data sources, indicators, countries, Esync’s answers** → `js/config.js` (look for `TODO`).
- **Vision / mission / objectives and page text** → `index.html`.
- **Colours** → the variables at the top of `css/style.css`.

> The vision, mission and objectives are **draft wording** — replace them with ESC’s official statements.

## Upgrade Esync to a real AI model (later)

Esync currently answers from the built-in knowledge list plus live dashboard figures, so it works with no server.
To connect a real model (e.g. the Claude API), create a tiny backend (Cloudflare Workers, Vercel or Netlify function) that:

1. accepts `POST { message, history }`,
2. calls the AI provider with **your API key stored as a server secret**,
3. returns `{ "reply": "..." }`.

Then set `esyncApiUrl` in `js/config.js` to that endpoint. **Never put an API key in the website files** — anyone can read them. If the backend fails, Esync automatically falls back to the built-in answers.

## Notes

- Dashboard and Data hub numbers come from the World Bank API in the visitor’s browser. The latest year may lag; always cite the source.
- Please check each link in `dataSources` before launch.
- Regression results are for learning. Time-series regressions can be spurious — encourage members to think about causation, stationarity and omitted variables.

## Ideas for the next version

- Add Brunei-specific datasets (DEPS/BDCB) as CSV files in a `data/` folder and chart them.
- Add multiple regression, residual plots and forecasting.
- Events calendar, team page, blog/research page, member sign-up form (Google Forms or Formspree).
- Malay language toggle (EN / BM).
